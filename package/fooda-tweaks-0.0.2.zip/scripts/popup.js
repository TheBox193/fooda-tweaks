'use strict';

console.log('Fooda fooda! Popup');