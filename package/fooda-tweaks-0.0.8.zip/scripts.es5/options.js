'use strict';

window.console.log('\'Allo \'Allo! Option');